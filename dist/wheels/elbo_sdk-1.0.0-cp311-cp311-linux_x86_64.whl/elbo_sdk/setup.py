from pathlib import Path

from setuptools import Extension, setup


def _discover_compiled_modules(pkg_dir: Path) -> list[str]:
    # CMake drops compiled modules into this package directory as <name>.so/.pyd.
    module_files = [*pkg_dir.glob("*.so"), *pkg_dir.glob("*.pyd")]
    return sorted({p.stem for p in module_files})


def _make_stub_extensions(mod_names: list[str]) -> list[Extension]:
    return [Extension(f"elbo_sdk.{name}", sources=[]) for name in mod_names]


def main() -> None:
    pkg_dir = Path(__file__).parent
    mod_names = _discover_compiled_modules(pkg_dir)
    extensions = _make_stub_extensions(mod_names)

    setup(ext_modules=extensions)


if __name__ == "__main__":
    main()
